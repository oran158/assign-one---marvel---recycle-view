package com.example.myapplicationrecyclerview.data

import com.example.myapplicationrecyclerview.models.BlogPost

class DataSource {

    companion object {

        fun createDataSet(): ArrayList<BlogPost> {
            val list = ArrayList<BlogPost>()
            list.add(
                BlogPost(
                    0,
                    "THOR",
                    "Thor Odinson, more commonly known as Thor, and sometimes by his title as the God of Thunder, is a superhero portrayed by Chris Hemsworth in the Marvel Cinematic Universe (MCU) media franchise, based on the Marvel Comics character of the same name and the Norse mythological god of the same name.",
                    "https://upload.wikimedia.org/wikipedia/en/3/3c/Chris_Hemsworth_as_Thor.jpg",
                    "https://static.wikia.nocookie.net/disney/images/4/4a/Thor_Odinson_TDW_poster_textless.jpg/revision/latest?cb=20130615173905",
                    "Chris Hemsworth"
                )
            )
            list.add(
                BlogPost(
                    1,
                    "IRON MAN",
                    "Iron Man is a 2008 American superhero film based on the Marvel Comics character of the same name.",
                    "https://playcontestofchampions.com/wp-content/uploads/2021/11/champion-iron-man-infinity-war-720x720.jpg",
                    "https://bamsmackpow.com/files/image-exchange/2018/08/ie_23207-850x560.jpeg",
                    "Robert Downey Jr."
                )
            )

            list.add(
                BlogPost(
                    2,
                    "HULK",
                    "The Hulk is a fictional superhero appearing in publications by the American publisher Marvel Comics.",
                    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvEmbAzzleQ9lakE0nuGCl6e-S9QInt1ZkaQ&usqp=CAU",
                    "https://cdn.vox-cdn.com/thumbor/Pvdo1lFYBBDbEG54FLW4tJ4pUcM=/0x0:2100x1181/1200x800/filters:focal(909x410:1245x746)/cdn.vox-cdn.com/uploads/chorus_image/image/67426099/experience_avengers_day.0.jpg",
                    "Mark Ruffalo"
                )
            )
            list.add(
                BlogPost(
                    3,
                    "CAPTAIN AMERICA",
                    "Captain America is a superhero appearing in American comic books published by Marvel Comics.",
                    "https://wegotthiscovered.com/wp-content/uploads/2021/09/image1-20-640x321.jpg",
                    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6bRc_cXvXZnntRY5woIXFN0ie72AJpptIOg&usqp=CAU",
                    "Chris Evans"
                )
            )
            list.add(
                BlogPost(
                    4,
                    "SPAIDERMAN",
                    "Spider-Man is a superhero appearing in American comic books published by Marvel Comics.",
                    "https://cdn.mos.cms.futurecdn.net/8ZZNSej9H2oqYzpa5K422b-1200-80.jpg",
                    "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/spider-man-1627065947.jpeg",
                    "Tom Holland"
                )
            )
            list.add(
                BlogPost(
                    5,
                    "BLACK PANTHER",
                    "A black panther is the melanistic colour variant of the leopard (Panthera pardus) and the jaguar (Panthera onca). Black panthers of both species have excess black pigments, but their typical rosettes are also present.",
                    "https://upload.wikimedia.org/wikipedia/en/9/9f/Black_Panther_OS_Vol_1_2.png",
                    "https://media.newyorker.com/photos/5a87650156b75c08a3e5bbb6/1:1/w_2400,h_2400,c_limit/Cobb-Black-Panther.jpg",
                    "Chadwick Boseman"
                )
            )
            list.add(
                BlogPost(
                    6,
                    "ANT MAN",
                    "Ant-Man is the name of several superheroes appearing in books published by Marvel Comics.",
                    "https://image.tmdb.org/t/p/w500/s0Sl2YemtW2ZwhkrrKksbTUja1L.jpg",
                    "https://sspthinksfilm.files.wordpress.com/2015/07/ant-man-costume.jpg",
                    "Paul Rudd"
                )
            )
            list.add(
                BlogPost(
                    7,
                    "doctor stange ",
                    "Doctor Stephen Strange is a fictional character appearing in American comic books published by Marvel Comics.",
                    "https://cdn.mos.cms.futurecdn.net/ipBHDYLVrAC7X4viETrJTD.jpg",
                    "https://hips.hearstapps.com/digitalspyuk.cdnds.net/18/14/1522871679-aif6.jpg?resize=480:*",
                    "Benedict Timothy Carlton Cumberbatch"
                )
            )
            return list
        }
    }
}