package com.example.myapplicationrecyclerview.models



data class BlogPost  (
    var id:Long,
    var title: String,
    var body: String,
    var image: String,
    var image2: String,
    var userName: String

) {

}